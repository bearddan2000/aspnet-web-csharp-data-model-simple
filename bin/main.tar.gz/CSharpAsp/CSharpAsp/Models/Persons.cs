﻿using System;
namespace CSharpAsp.Models
{
    public class Persons
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
