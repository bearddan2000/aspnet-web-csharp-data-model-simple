﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;

namespace CSharpAsp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var people = new Models.Persons() { Name = @"Adam", Age = 0 };

            return View(people);
        }
    }
}
